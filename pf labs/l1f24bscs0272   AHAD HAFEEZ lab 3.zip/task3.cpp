#include<iostream>
#include<fstream>
using namespace std;
int main()  {
	float arr[100];


	ifstream file;
	file.open("input.txt");
		
	if (!file){
		cout << "file not open";
	}
		int count =0;
		char comma;
		while (file >> arr[count]){

			count++;
			file >> comma;
		}
		
		for (int i = 0; i < count; i++){
			cout << arr[i] << "   "; 
		}




	}
