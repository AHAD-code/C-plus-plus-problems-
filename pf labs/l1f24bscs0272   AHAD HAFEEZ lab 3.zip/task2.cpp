#include<iostream>
#include<fstream>
using namespace std;

int main()

{

	ofstream write;
	write.open("student.txt");
	if (!write) {
		cout << "file not open";
	}
	char roll[20];
	char name[10];
	float marks;
	while (true) {
		cout << "enter roll number :";
		cin >> roll;
		cout << "enter name: ";
		cin >> name;
		cout << "enter marks:";
		cin >> marks;
		write << roll << "  " << name << "   " << marks << endl;
		cout << "record successfully add in file" << endl;



	}
	write.close();

}