#include<iostream>
#include<fstream>
using namespace std;
int main() {

	char line[100];
	int roll, marks;
	char name[15];
	 
	ifstream file;

	file.open("students.txt");
	if (!file) {
		cout << "file not open";
	}
	cout << "whole data line by line" << endl;

	while (file.getline(line, 100)) {

		cout << line << endl;
	}
	file.close();
	cout << "roll number in seperate line:" << endl;
	file.open("students.txt");
	while (file >> roll >> name >> marks) {
		cout << roll << endl;
	}

	file.close();
	cout << " names of students in separate lines" << endl;
	file.open("students.txt");
	while (file >> roll >> name >> marks) {
		cout << name<< endl;
	}

	file.close();
	cout << "marks separated by space." << endl;
	file.open("students.txt");
	while (file >> roll >> name >> marks) {
		cout << marks << " ";
	}

	file.close();
	cout << " display only Roll No and name" << endl;
	file.open("students.txt");
	while (file >> roll >> name >> marks) {
		cout << roll << "   " << name << endl;
	}

	file.close();
	cout << "display only name and marks" << endl;
	file.open("students.txt");
	while (file >> roll >> name >> marks) {
		cout <<name << "   " << marks<< endl;
	}

	file.close();




}