#include<iostream>
#include<fstream>
using namespace std;
int main() 
{
	ofstream out;
	out.open("output.txt");
	if (!out) {
		cout << "file not open";
	}
	for (int i = 0; i < 10; i++) {
		out << i << " ";
	}
	out.close();
	 
	int  a;
	int sum = 0;
	
	ifstream read;
	read.open("output.txt");
	if (!out) {
		cout << "file not open";
	}
	read >> a;
	while (!read.eof()){
		cout << a;
		read >>a;
		sum = sum + a;
		
		
	}
	read.close();
	cout << "  sum =" << sum;
	

		return 0;

}