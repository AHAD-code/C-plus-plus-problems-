#include <iostream>
#include <fstream>

using namespace std;

int main() {
    char id[25], title[20], Author[15], genre[10];
    int price;
    int choice;
    ofstream file;
    file.open("data.txt", ios::app);
    if (!file) {
        cout << "File could not be opened!" << endl;
        return 1;
    }

    do {
        cout << "\n1. Write book record" << endl;
        cout << "2. Display all data" << endl;
        cout << "3. Search by ID" << endl;
        cout << "4. Display books of a specific genre" << endl;
        cout << "5. Display books under a specific price" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter book ID: ";
            cin >> id;
            cout << "Enter book title: ";
            cin >> title;
            cout << "Enter book author: ";
            cin >> Author;
            cout << "Enter book genre: ";
            cin >> genre;
            cout << "Enter book price: ";
            cin >> price;
            file << id << " " << title << " " << Author << " " << genre << " " << price << endl;
            cout << "Book successfully added to file." << endl;
        }
        else if (choice == 2) {
            ifstream read("data.txt");
            if (!read) {
                cout << "File could not be opened!" << endl;
                continue;
            }
            cout << "\nBook Records:\n";
            while (read >> id >> title >> Author >> genre >> price) {
                cout << id << " " << title << " " << Author << " " << genre << " " << price << endl;
            }
            read.close();
        }
        else if (choice == 3) {
            char searchID[25];
            cout << "Enter book ID to search: ";
            cin >> searchID;
            ifstream read("data.txt");
            bool found = false;
            while (read >> id >> title >> Author >> genre >> price) {
                int i = 0, match = 1;
                while (searchID[i] != '\0' && id[i] != '\0') {
                    if (searchID[i] != id[i]) {
                        match = 0;
                        break;
                    }
                    i++;
                }
                if (match && searchID[i] == '\0' && id[i] == '\0') {
                    cout << "Record found: " << endl;
                    cout << "book ID:" << id << endl;
                    cout << "book title: " << title << endl;
                    cout << " Author:" << Author << endl;
                    cout << "Genre: " << genre << endl;
                    cout<<" " << price << endl;
                    found = true;
                    break;
                }
            }
            if (!found) {
                cout << "Record not found." << endl;
            }
            read.close();
        }
        else if (choice == 4) {
            char searchGenre[10];
            cout << "Enter genre to search: ";
            cin >> searchGenre;
            ifstream read("data.txt");
            bool found = false;
            cout << "\nBooks in genre " << searchGenre << ":" << endl;
            while (read >> id >> title >> Author >> genre >> price) {
                int i = 0, match = 1;
                while (searchGenre[i] != '\0' && genre[i] != '\0') {
                    if (searchGenre[i] != genre[i]) {
                        match = 0;
                        break;
                    }
                    i++;
                }
                if (match && searchGenre[i] == '\0' && genre[i] == '\0') {
                    cout << id << " " << title << " " << Author << " " << genre << " " << price << endl;
                    found = true;
                }
            }
            if (!found) {
                cout << "No books found in this genre." << endl;
            }
            read.close();
        }
        else if (choice == 5) {
            int maxPrice;
            cout << "Enter maximum price: ";
            cin >> maxPrice;
            ifstream read("data.txt");
            bool found = false;
            cout << "\nBooks under price " << maxPrice << ":" << endl;
            while (read >> id >> title >> Author >> genre >> price) {
                if (price < maxPrice) {
                    cout << id << " " << title << " " << Author << " " << genre << " " << price << endl;
                    found = true;
                }
            }
            if (!found) {
                cout << "No books found under this price." << endl;
            }
            read.close();
        }
        else if (choice == 6) {
            cout << "Exiting program." << endl;
            break;
        }
        else {
            cout << "Invalid choice, please try again." << endl;
        }
    } while (true);

    file.close();
    return 0;
}
