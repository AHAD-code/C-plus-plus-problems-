#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char word[100];
	cout << "enter the word(without spaces):";
	cin >> word;
	ofstream file;
	file.open("data.txt");
	file << word;
	int count = 0;
	while (word[count] != '\0') {
		count++;
	}
	cout << "word: " << word << endl;
	cout << " character: "<<count;





}