#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float num;
	cout << "enter floating number:";
	cin >> num;
	cout << "Square root of " << num << " is: " << sqrt(num) << endl;
	cout << num << " raised to the power of 3 is: " << pow(num, 3) << endl;


	return 0;

}