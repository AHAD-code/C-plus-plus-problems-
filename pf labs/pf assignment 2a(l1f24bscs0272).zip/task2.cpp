#include<iostream>
using namespace std;
float add(float a, float b) 
{
    return a + b;
}

float subtract(float a, float b) 
{
    return a - b;
}

float multiply(float a, float b)
{
    return a * b;
}

float divide(float a, float b)
{
    return a / b;
}

int modulus(int a, int b) {
    return a % b;
}
float power(float base, int exponent)
{
    float result = 1;
    for (int i = 0; i < exponent; i++) {
        result *= base;
    }
    return result;
}
int main() {
    float num1, num2;

    int choice, exp;

    cout << "Enter two numbers:";

    cin >> num1 >> num2;
    cout << "Select operation:" << endl;
    cout << "1. Addition" << endl;
    cout << "2. Subtraction"<<endl;
    cout << "3. Multiplication" << endl;
    cout << "4. Division" << endl;
    cout << "5. Modulus" << endl;
    cout << "6. Exponentiation" << endl;
    cout << "Enter your choice (1-6):" << endl;
    cin >> choice;
    switch (choice) {
    case 1:
        cout << "Result:" << add(num1, num2) << endl;
        break;
    case 2:
        cout << "Result:" << subtract(num1, num2) << endl;
        break;
    case 3:
        cout << "Result:" << multiply(num1, num2) << endl;
        break;
    case 4:
        if (num2 != 0) {
            cout << "Result:" << divide(num1, num2) << endl;
        }
        else {
            cout << "Error! Division by zero." << endl;
        }
        break;
    case 5:
        cout << "Result: " << modulus((int)num1, (int)num2) << endl;
        break;
    case 6:
        cout << "Enter exponent:";
        cin >> exp;
        cout << "Result of first number: " << power(num1,exp) << endl;
        cout << "Result of second number: " << power(num2, exp) << endl;
        break;
    default:
        cout << "Invalid choice.";
    }

    return 0;
}


