#include<iostream>
#include<cmath>
using namespace std;
void min_max(int array[], int size, int &min, int &max) {
	min = array[0];
	max = array[0];
	for (int i = 0; i < size; i++) {
		if (max < array[i]) {
			max = array[i];
		}
		if (min > array[i]) {
			min = array[i];
		}
	}

}
void even_odd(int array[],int size,int &even,int &odd) {
	even = 0;
	odd = 0;
	for (int i = 0; i < size; i++) {
		if (array[i] % 2 == 0) {
			even++;
		}
		else {
			odd++;
		}
	}
}
float find_average(int array[], int size) {
	int  sum = 0;
	for (int i = 0; i < size; i++) {
		sum = sum + array[i];
	}
	return sum / size;
}
float findStandardDeviation(int arr[], int size, float average) {
	float sum = 0;
	for (int i = 0; i < size; i++) {
		sum += pow(arr[i] - average, 2);
	}
	return sqrt(sum / size);
}



int main()
{
	const int size = 5;
	int array[size];
	cout << "enter " << size << " elements: " << endl;
	for (int i = 0; i < size; i++) {
		cin >> array[i];
	}
	int max, min, even, odd;
	float average, stddev;

	min_max(array, size, min, max);
	even_odd(array, size,even,odd);
	average = find_average(array, size);
	stddev = findStandardDeviation(array, size, average);

	cout << "Maximum: " << max << endl;
	cout << "Minimum: " << min << endl;
	cout << "Even numbers: " << even << endl;
	cout << "Odd numbers: " << odd << endl;
	cout << "Average: " <<average << endl;
	cout << "Standard Deviation: " << stddev<< endl;


	return 0;
}