#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	char array1[100];
	char array2[100];
	cout << "Enter first array:";
	cin.getline(array1, 100);
	cout << "enter second array:";
	cin.getline(array2, 100);
	cout << "length of first array:" << strlen(array1) << endl;
	cout << "length of second array:" << strlen(array2) << endl;
	int result = strcmp(array1, array2);
	if (result == 0) {
		cout << "both array are equal" << endl;
	}
	else if (result < 0) {
		cout << "first array less than second" << endl;
	}
	else if (result > 0) {
		cout << "first array greater than second" << endl;
	}
	strcat_s(array1, array2);
	cout << "Concatenated : " << array1 << endl;
	char copyarray[200];
	strcpy_s(copyarray, array1);
	cout << "Copied string: " << copyarray << endl;


	return 0;
}