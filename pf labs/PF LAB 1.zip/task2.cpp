#include<iostream>
using namespace std;
int main()
{

	int num;
	cout << "enter number";
	cin>>num;
	if (num >= 90 && num <= 100){
		cout << "Grade=A";
	}
	else if (num >= 80 && num <=89){
		cout << "Grade=B";
	}
	else if (num >= 70 && num <= 79){
		cout << "Grade=C";
	}
	else if (num >= 60 && num <= 69){
		cout << "Grade=C";
	}
	else if(num>=0&&num<=59){
		cout << "Grade=F";
	}
	else{
		cout << "incorect input";
	}
	return 0;


}