#include<iostream>
using namespace std;
int main()
{

	int num;
	cout << "enter number:";
	cin >> num;
	cout << "even numbers:";
	for (int i = 0; i<=num; i++){
		if (i % 2 == 0){
			cout << i<<" ";
		}
	}

	return 0;




}