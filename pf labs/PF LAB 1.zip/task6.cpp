#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter the number of rows:";
	cin >> num;
	int a = num / 2;
	for (int i = num / 2; i > 0; i--) {
		for (int j =0; j <i; j++) {
			cout << " ";
		}
		for (int j=0;j<=a-i; j++) {
			cout << "* ";
		}
		cout << endl;
	}
	for (int i = num / 2; i >=0; i--) {
		for (int j = 0; j <a-i; j++) {
			cout << " ";
		}
		for (int j =0; j <=i; j++) {
			cout << "* ";
		}
		cout << endl;
	}



}