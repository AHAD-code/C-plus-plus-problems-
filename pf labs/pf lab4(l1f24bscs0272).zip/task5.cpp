#include<iostream>
using namespace std;
int cube(int a) {
	int cube = a * a * a;
	return cube;
}
int main() {
	int num;
	cout << "enter number:";
	cin >> num;
	int cub=cube(num);
	cout << "cube of num:";
	cout << cub;

}