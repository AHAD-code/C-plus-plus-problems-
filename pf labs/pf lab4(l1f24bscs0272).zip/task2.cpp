#include<iostream>
#include<fstream>
using namespace std;

void attendance() {
	ifstream fin("students.txt");
	
	char roll[20];
	char name[30];
	int age;
	char	department[20];
	while (fin.getline(roll, 20, ',')) {
		
		
		
		fin.getline(name, 30, ',');
		fin >> age;
		fin.get();
		fin.getline(department,20);
		int total_class = 0;
		float present = 0;
		ifstream fin1("attendance.txt");
		char roll1[20];
		char date[15];
		char status[20];
		while (fin1.getline(roll1, 20, ',')) {

			
			
			
			
			
			
			fin1.getline(date, 15, ',');
			fin1.get();
			fin1.getline(status, 20);
			
			
			bool a = true;;

			for (int i = 0; roll[i] != '\0'; i++) {
				
					if (roll[i] != roll1[i]) {
						a = false;
						break;
						
					}
					

			}
			
			if (a) {
				if (status[0]=='P') {
					present++;
				}
			}
			if (a) {
				
				total_class++;
			}
			
			
		}
		if (total_class!= 0) {
			float percentage = (present / total_class) * 100;
			fin1.close();
			cout << roll << "  attendence percentage:" << percentage <<"%" << endl;
		}
	}
	
	

}

int main()

{

	attendance();




}