#include<iostream>
#include<fstream>
using namespace std;

int students() {
	ifstream fin("students.txt");
	if (!fin) {
		cout << "file student.txt not open:";
	}
	char roll[20];
	char name[30];
	int age;
	char	department[20];
	int count = 0;
	while (!fin.eof()) {
		fin.getline(roll, 20, ',');
		fin.getline(name, 30, ',');
		fin >> age;
		fin.get();
		fin.getline(department, 10);
		
		count++;
	}


	fin.close();
	return count;
}

void attendance(int count) {
	char roll[20];
	char name[30];
	int age;
	char	department[20];
	ofstream file("attendance.txt", ios::app);
	ifstream  fin("students.txt");
	if (!file) {
		cout << "Unable to open attendance.txt\n";

	}
	char date[20];
	cout << "Enter today's date (YYYY-MM-DD): ";
	cin >> date;
	for (int i = 0; i < count; i++) {
		fin.getline(roll, 20, ',');
		fin.getline(name, 30, ',');
		fin >> age;
		fin.get();
		fin.getline(department, 10);
		char status[10];
		cout << " enter status(present/absent) for  " << roll << ":";
		cin >> status;
		file << roll << "  ," << date << " ,  " << status << endl;

	}
	cout << endl;
	cout << "you take atendance sucssesfully" << endl;




}


int main()
{
	int total = students();
	attendance(total);
	cout << total;
}