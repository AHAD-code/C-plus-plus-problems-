#include<iostream>
using namespace std;
int even_odd(int num) {
	if (num % 2 == 0) {
		cout << "number is even";
	}
	else {
		cout << "number is odd";
	}
	return 0;
}
int main() {
	int num;
	cout << "enter number:";
	cin >> num;
	even_odd(num);

}