#include<iostream>
#include<fstream>
using namespace std;

int main() {
	while (true) {
		char roll1[20];
		cout << "enter roll number for delete student record:";
		cin >> roll1;
		ifstream fin("students.txt");
		ofstream temp("temp.txt");
		if (!fin) {
			cout << "file student.txt not open:";
		}
		char roll[20];
		char name[30];
		int age;
		char	department[20];
		while (fin.getline(roll, 20, ',')) {

			fin.getline(name, 30, ',');
			fin >> age;
			fin.get();
			fin.getline(department, 10);
			bool a = true;
			for (int i = 0; roll[i] != '\0'; i++) {
				if (roll[i] != roll1[i]) {
					a = false;
				}
			}
			if (!a) {
				temp << roll << "," << name << "," << age << "," << department << endl;
			}

		}
		fin.close();
		temp.close();

		ofstream fout("students.txt");
		ifstream file("temp.txt");
		while (file.getline(roll, 20, ',')) {

			file.getline(name, 30, ',');
			file >> age;
			file.get();
			file.getline(department, 10);
			fout << roll << "," << name << "," << age << "," << department << endl;
		}
		fout.close();
		file.close();
		ifstream fin1("attendance.txt");
		ofstream file1("temp.txt");

		char date[15];
		char status[20];
		while (fin1.getline(roll, 20, ',')) {







			fin1.getline(date, 15, ',');
			fin1.get();
			fin1.getline(status, 20);
			bool a = true;
			for (int i = 0; roll[i] != '\0'; i++) {
				if (roll[i] != roll1[i]) {
					a = false;
				}
			}
			if (!a) {
				file1 << roll << "," << name << "," << age << "," << department << endl;
			}
			fin.close();
			file1.close();
		}
		ofstream out("attendance.txt");
		ifstream fil("temp.txt");
		while (fil.getline(roll, 20, ',')) {

			fil.getline(name, 30, ',');
			fil >> age;
			fil.get();
			fil.getline(department, 10);
			out << roll << "," << name << "," << age << "," << department << endl;
		}
		out.close();
		fil.close();

		ifstream fin2("warnings.txt");
		ofstream temp1("temp.txt");
		if (!fin2) {
			cout << "file student.txt not open:";
		}




		while (fin2.getline(roll, 20, ',')) {

			fin2.getline(name, 30, ',');
			fin2 >> age;
			fin2.getline(department, 10);
			bool a = true;
			for (int i = 0; roll[i] != '\0'; i++) {
				if (roll[i] != roll1[i]) {
					a = false;
				}
			}
			if (!a) {
				temp1 << roll << "," << name << "," << age << "," << department << endl;
			}

		}
		fin2.close();
		temp.close();
		ofstream fou("warnings.txt");
		ifstream file2("temp.txt");
		while (file2.getline(roll, 20, ',')) {

			file2.getline(name, 30, ',');
			file2 >> age;
			file2.get();
			file2.getline(department, 10);
			fout << roll << "," << name << "," << age << "," << department << endl;
		}
		fou.close();
		file2.close();
		cout << "delete record sucssesfully:" << endl;
	}
}