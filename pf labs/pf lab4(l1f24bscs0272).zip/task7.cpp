#include<iostream>
using namespace std;
float area(int a) {
	
	return (3.14 * a * a);
}
float circumference(int a)
{
	float b = 2 * 3.14 * a;
		return b;
}

int main()
{
	int radius;
	cout << "enter radius of circle:";
	cin >> radius;
	cout << "area of circle:";
	float a= area(radius);
	cout << a;
	cout << endl;
	cout << "circumference:";
	float b = circumference(radius);
	cout << b;


}