#include<iostream>
using namespace std;
void swap(int* a, int* b) {
	int temp = *a;
	*a = *b;
	*b = temp;
}
int main()
{
	int a;
	int b;
	cout << "enter value of a:";
	cin >> a;
	cout << "enter value of b:";
	cin >> b;
	swap(&a, &b);
	cout << "value of a:" << a << endl;
	cout << "value of b:" << b;
	return 0;





}