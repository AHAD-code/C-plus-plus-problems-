#include <iostream>
using namespace std;

void reverseArray(int* start, int* end) {
    while (*start< *end) {
       
        int temp = *start;
        *start = *end;
        *end = temp;

       
        start++;
        end--;
    }
}
void displayArray(int* arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << *(arr + i) << " ";
    }
    cout << endl;
}

int main() {
    const int SIZE = 5;
    int arr[SIZE];

    cout << "Enter 5 numbers: ";
    for (int i = 0; i < SIZE; i++) {
        cin >> arr[i];
    }

    cout << "Original array: ";
    displayArray(arr, SIZE);

    
    reverseArray(arr, arr + SIZE - 1);

    cout << "Reversed array: ";
    displayArray(arr, SIZE);

    return 0;
}
