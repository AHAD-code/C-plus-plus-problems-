#include<iostream>
#include<fstream>

using namespace std;

int main() {
	const int size = 5;
	int a[size];
	cout << "enter elements of array:";
	for (int i = 0; i < size; i++) {
		cin >> a[i];
	}
	int *ptr =a;
	
	ofstream fout;
	fout.open("data.txt");
	for (int i = 0; i < size; i++) {
		fout << *(ptr + i) << " ";
	}
	fout.close();
	ifstream fin;
	fin.open("data.txt");
	cout << "values read from file:" << endl;
	for (int i = 0; i < size; i++) {
		fin >> *(ptr + i);
		cout << *(ptr + i);
	}
	fin.close();
	
	return 0;


}