#include <iostream>

using namespace std;



void countEvenOdd(int* arr, int size, int* evenCount, int* oddCount) {
    *evenCount = 0;
    *oddCount = 0;
    for (int i = 0; i < size; i++) {
       
        int val = *(arr + i);
        if (val % 2 == 0) {
            (*evenCount)++;
        }
        else {
            (*oddCount)++;
        }
    }
}

int main() {
    const int SIZE = 10;
    int arr[SIZE];
    int evenCount, oddCount;

    cout << "Enter 10 numbers: ";
    for (int i = 0; i < SIZE; i++) {
        cin >> arr[i];
    }

    
    countEvenOdd(arr, SIZE, &evenCount, &oddCount);

    cout << "Even numbers count: " << evenCount << endl;
    cout << "Odd numbers count: " << oddCount << endl;

    return 0;
}
