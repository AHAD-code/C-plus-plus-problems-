#include<iostream>
using namespace std;
int max(int* ptr, int size) {
	int max = *ptr;
	for (int i = 0; i < size; i++) {
		if (max < *(ptr + i)) {
			max = *(ptr + i);
		}
	}
	
	return max;
}
int main() {
	const int size = 5;
	int a[size];
	
	cout << "enter elements of array:";
	for (int i = 0; i <size; i++) {
		cin >> a[i];
	}
	int maximum = 0;
	maximum = max(a, size);
	cout << "max :" << maximum;
	return 0;

	
}