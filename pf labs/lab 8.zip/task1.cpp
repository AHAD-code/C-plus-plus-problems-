#include<iostream>
using namespace std;
int main()
{

	int x = 10;
	int* ptr =&x;
	cout << "value of x using variable:  " << x << endl;
	cout << "value of x using pointer:  " << *ptr << endl;
	cout << " address of x using variable:  " <<&x << endl;
	cout << " address of x using pointer:  " <<ptr << endl;

	return 0;




}