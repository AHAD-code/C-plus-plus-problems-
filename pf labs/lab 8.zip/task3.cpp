#include<iostream>
using namespace std;
int main() {

	int a[5];
	int * ptr = a;
	cout << "enter elements of array:";
	for (int i = 0; i < 5; i++) {
		cin >> a[i];
	}
	cout << "array elements using pointers:" << endl;
	for (int i = 0; i < 5; i++) {
		cout << *(ptr + i) << endl;
	}
	return 0;


}