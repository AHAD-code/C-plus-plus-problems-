#include <iostream>
using namespace std;

int main() {
    int mat[3][3];
    cout << "Enter 9 elements: ";
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            cin >> mat[i][j];
        }
    }

    
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            if (mat[i][j] % 2 == 0)
                mat[i][j] = 0;

    cout << "Modified matrix:\n";
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j)
            cout << mat[i][j] << " ";
        cout << endl;
    }

    return 0;
}
