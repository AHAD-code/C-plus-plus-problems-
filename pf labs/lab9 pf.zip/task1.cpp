#include<iostream>
using namespace std;
int sumptr(int* ptr1, int* ptr2) {
	cout << "enter first value:";
	cin >> *ptr1;
	cout << "enter second value:";
	cin >> *ptr2;
	return(*ptr1 + *ptr2);
}
int main()
{
	int a, b;
	int* ptr1 = &a;
	int* ptr2 = &b;
	int sum = sumptr(ptr1, ptr2);
	cout << "sum:" << sum;


	return 0;




}