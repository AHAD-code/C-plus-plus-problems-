#include <iostream>
using namespace std;

int square(int x) {
    return x * x;
}

void squareArray(int* ptr, int size) {
    for (int i = 0; i < size; i++) {
        *(ptr + i) = square(*(ptr + i));
    }
}

int main() {
    int arr[5];
    cout << "Enter 5 numbers: ";
    for (int i = 0; i < 5; i++) {
        cin >> arr[i];
    }
    int* ptr = arr;
    squareArray(arr, 5);

    cout << "Array after squaring: ";
    for (int i = 0; i < 5; i++) 
    {
        cout << *ptr <<" ";
        ptr++;

    }

    return 0;
}
