#include <iostream>
using namespace std;

int search(int* arr, int size, int num) {
    for (int i = 0; i < size; ++i) {
        if (*(arr + i) == num) return i;
    }
    return -1;
}

int main() {
    int arr[6];
    cout << "Enter 6 numbers: ";
    for (int i = 0; i < 6; ++i)
    {
        cin >> arr[i];
    }

    int num;
    cout << "Enter number to search: ";
    cin >> num;

    int index = search(arr, 6, num);
    cout << "Number found at index: " << index << endl;

    return 0;
}
