#include <iostream>
using namespace std;

int main() {
    int mat[3][3];
    bool isIdentity = true;

    cout << "Enter 9 elements: ";
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> mat[i][j];
        }
    }
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (i == j && mat[i][j] != 1)
                isIdentity = false;
            else if (i != j && mat[i][j] != 0)
                isIdentity = false;
        }
    }
    if (isIdentity)
        cout << "This is an identity matrix." << endl;
    else
        cout << "This is NOT an identity matrix." << endl;

    return 0;
}
