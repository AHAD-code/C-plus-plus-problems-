#include <iostream>
using namespace std;

int* reverseDigits(int num, int& size) {
    int temp = num;
    size = 0;

    
    while (temp != 0) {
        temp /= 10;
        size++;
    }

    int* arr = new int[size];
    for (int i = 0; i < size; i++) {
        arr[i] = num % 10;
        num /= 10;
    }

    return arr;
}

int main() {
    int number, size;
    cout << "Enter a number: ";
    cin >> number;

    int* reversedArray = reverseDigits(number, size);

    cout << "Digits in reverse order: ";
    for (int i = 0; i < size; i++) {
        cout << reversedArray[i] << " ";
    }
    cout << endl;

    delete[] reversedArray; 
    return 0;
}
