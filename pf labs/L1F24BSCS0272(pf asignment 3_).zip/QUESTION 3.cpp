#include <iostream>
using namespace std;

int* reverseDigits(int num, int& size) {
    int temp = num;
    size = 0;
    while (temp != 0) {
        temp /= 10;
        size++;
    }
    int* arr = new int[size];
    for (int i = 0; i < size; i++) {
        arr[i] = num % 10;
        num /= 10;
    }
    return arr;
}

int* addArrays(int* arr1, int size1, int* arr2, int size2,int& resultSize) {
    int biggerSize;

    if (size1 > size2)
        biggerSize = size1;
    else
        biggerSize = size2;

    resultSize = biggerSize + 1;
    int* result = new int[resultSize];

    int carry = 0;
    int i = 0;

    while (i < size1 || i < size2) {
        int digit1 = 0;
        if (i < size1)
            digit1 = arr1[i];

        int digit2 = 0;
        if (i < size2)
            digit2 = arr2[i];

        int sum = digit1 + digit2 + carry;

        result[i] = sum % 10;   // Store last digit of sum
        carry = sum / 10;       // Store remaining carry for next addition

        i++; // Move to next position
    }


    if (carry != 0) {
        result[i] = carry;
        i = i + 1;
    }

    resultSize = i;
    return result;
}

int arrayToInteger(int* arr, int size) {
    int num = 0;
    for (int i = size - 1; i >= 0; i--) {
        num = num * 10 + arr[i];
    }
    return num;
}

int main() {
    int num1, num2;
    cout << "Enter first number: ";
    cin >> num1;
    cout << "Enter second number: ";
    cin >> num2;

    int size1, size2;
    int* array1 = reverseDigits(num1, size1);

    int* array2 = reverseDigits(num2, size2);

    int resultSize ;

    int* resultArray = addArrays(array1, size1, array2, size2, resultSize); 

    int result_num = arrayToInteger(resultArray, resultSize);

    cout << "array1: ";
    for (int i = 0; i < size1; i++) cout << array1[i] << ",";
    cout << endl;

    cout << "array2: ";
    for (int i = 0; i < size2; i++) cout << array2[i] << ",";
    cout << endl;

    cout << "result_Array: ";
    for (int i = 0; i < resultSize; i++) cout << resultArray[i] << ",";
    cout << endl;

    cout << "result_num = " << result_num << endl;

    delete[] array1;
    delete[] array2;
    delete[] resultArray;

    return 0;
}
