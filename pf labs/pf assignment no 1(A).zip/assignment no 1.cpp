#include<iostream>
#include<fstream>
using namespace std;
void addrecord() {
	ofstream fout("students.txt",ios::app);
	int roll;
	char name[15];
	int marks[3];
	cout << "enter roll number:";
	cin >> roll;
	cin.ignore();
	cout << "enter name:";
	cin.getline(name,15);
	cout << "enter marks in 3 subjects:";
	for (int i =0; i <3; i++) {
		
		cin>>marks[i];
	}
	fout << roll << "  " << name << ",   " << marks[0] << "  " << marks[1] <<"  " << marks[2] << endl;
	fout.close();
	cout << "student record add succesfully:" << endl;

}
void display_record() {
	int roll;
	char name[15];
	int marks[3];
	ifstream fin("students.txt");
	int total = 0;
	float average = 0;
	while (fin>> roll) {
		
		fin.ignore();
		fin.getline(name, 20,',');
		fin >> marks[0] >> marks[1] >> marks[2];
		total = marks[0] + marks[1] + marks[2];
		average = total / 3.0;
		cout << "\nRoll No: " << roll << endl;
		cout << "Name: " << name << endl;
		cout << "Marks: " << marks[0] << " " << marks[1] << " " << marks[2] << endl;
		cout << "Total: " << total << endl;
		cout << "Average: " << average << endl;
		cout << endl;

	}
	fin.close();
}
void search() {
	int roll;
	char name[15];
	int marks[3];
	ifstream fin("students.txt");
	int total = 0;
	float average = 0;
	int search;
	cout << "enter  roll number:";
	cin >> search;
	bool exist = false;
	while (fin>> roll) {
		fin.ignore();
		fin.getline(name, 20, ',');
		fin >> marks[0] >> marks[1] >> marks[2];
		total = marks[0] + marks[1] + marks[2];
		average = total / 3.0;
		if (roll == search) {
			exist = true;
			cout <<" found"<< endl;
			
			
			
			cout << "Name: " << name << ",  ";
			cout << "Marks: " << marks[0] << "  " << marks[1] << " " << marks[2] << ", ";
			cout << "Total: " << total << ",  ";
			cout << "Average: " << average << endl;
			cout << endl;
		}


	}
	if (!exist) {
		cout << "roll number not exist:";
	}
	fin.close();

}


int main()
{
	int choice;
	do{
		cout << "\n---- Student Record System ----\n";
		cout << "1. Add Student Record\n";
		cout << "2. Display All Records\n";
		cout << "3. Search Record by Roll Number\n";
		cout << "4. Exit\n";
		cout << "Enter choice: ";
		cin >> choice;
		if (choice == 1) {
			addrecord();
		}
		else if (choice == 2) {
			display_record();
		}
		else if (choice == 3) {
			search();
		}
		else {
			if (choice != 4) {
				cout << "invalid input" << endl;
			}
		}
	} while (choice != 4);
	cout << "program sucsessflly exit:";
	
	return 0;
}