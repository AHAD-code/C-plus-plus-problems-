#include<iostream>
#include<fstream>
using namespace std;
void display(char name[],int size) {
	cout << name << "  ";

}
void record() {
	ifstream fin("data.txt");
	if (!fin) {
		cout << "file ot open";
		return;
	}
	char name[20];
	int price, quantity;
	char first_line[100];
	fin.getline(first_line, 100);
	ofstream fout, fout1;
	fout.open("max.txt");
	fout1.open("quantity_less.txt");

	int max = 0;
	cout << "copied products:  ";
	while (fin >> name ) {
		fin >> price;
		fin>> quantity;
		display(name, 20);
		if (max < price) {
			max = price;
		} 


	}
	cout<<endl;
	fin.close();
	int count = 0;
	fin.open("data.txt");
	fin.getline(first_line, 100);
	cout << "maxmimum price product: ";
	while (fin >> name) {
		fin >> price;
		fin >> quantity;
		if (price == max) {
			fout << name << " " << quantity << endl;

			cout << name;
		}
		if (quantity< 200) {
			fout1 << name<< " " << quantity << endl;

			count++;
		}


	}
	cout << endl;
	fin.close();
	fout.close();
	fout1.close();

	cout << "number of items quantity less 200:  ";
	cout << count;
}



int main() {

	record();
	return 0;
}