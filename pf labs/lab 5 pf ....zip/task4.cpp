#include<iostream>
#include<fstream>
using namespace std;
void readfile() {
	char roll[20];
	char name[15];
	int age;
	char department[10];
	ifstream fin("students.txt");
	if (!fin) {
		cout << "file not open";
	}
	while (fin >> roll >> name >> age >> department) {
		
		cout << roll << "   " << name << "   "<<age << "   "<<department<< endl;
		
	}
	fin.close();
}

int main()
{

	readfile();
	return 0;
}