#include<iostream>
using namespace std;
void max_min(int a,int b) {
	if (a > b) {
		cout << "maximum between " << a << "and " << b << "is :  " << a << endl;
		cout << "Minimum between " << a << " and " << b << " is: " << b << endl;
	}
	else {
		cout << "maximum between " << a << "and " << b << "is :  " << b << endl;
		cout << "Minimum between " << a << " and " << b << " is: " << a << endl;
	}
}
char even_odd(int a) {
	if (a % 2 == 0) {
		return 'e';

	}
	else {
		return 'o';
	}
}


int main() {
	int num1;
	cout << "enter first number:";
	cin >> num1;
	int num2;
	cout << "enter second number:";
	cin >> num2;

	max_min(num1, num2);
	char result1 = even_odd(num1);
	char result2 = even_odd(num2);
	if (result1 == 'e') {
		cout << num1 << " is even  ";
	}
	else {
		cout << num1 << " is odd  ";
	}
	if (result2 == 'e') {
		cout << num2 << " is even  ";
	}
	else {
		cout << num2 << " is odd  ";
	}
	return 0;

}
