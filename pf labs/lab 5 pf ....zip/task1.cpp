#include<iostream>
using namespace std;
int sum(int arr[], int size, int &even_sum, int &odd_sum){

	for (int i = 0; i < size; i++){
		if (arr[i] % 2 == 0){
			even_sum = even_sum + arr[i];
		}
		else{
			odd_sum = odd_sum + arr[i];
		}
	}

	return 0;

}
void power(int (&arr2)[100], int arr[], int size){

	for (int i = 0; i < size; i++){
		arr2[i] = arr[i] * arr[i];
	}
}

int main()
{
	int even_sum = 0;
	int odd_sum = 0;
	int size;
	cout << "enter size of array:";
	cin >> size;
	int arr[100];
	int arr2[100];
	cout << "enter elements of array:";
	for (int i = 0; i < size; i++){
		cin >> arr[i];
	}
	sum(arr, size, even_sum, odd_sum);
	cout << "even number sum:" << even_sum << endl;
	cout << "odd number sum:" << odd_sum << endl;
	power(arr2, arr, size);
	cout << "power of each element in another array:";
	for (int i = 0; i < size; i++){
		cout << arr2[i] << " ";
	}

}