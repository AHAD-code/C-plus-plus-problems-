#include<iostream>
#include<fstream>
using namespace std;
void palindrome() {
	ifstream fin("input.txt");
	if (!fin) {
		cout << "file not open";
		return;
	}
	int a;
	cout << "palindrome numbers in file " << endl;
	while (fin >> a) {
		int num = a;
		int reverse = 0;
		while (num> 0) {
			int lastdigit = num % 10;
			reverse = reverse * 10 + lastdigit;
			num = num / 10;
		}
		if (reverse == a){ 
			cout << a << " ";
		}
	}


}
int main()
{

	palindrome();


}