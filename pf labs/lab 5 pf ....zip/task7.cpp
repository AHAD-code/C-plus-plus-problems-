#include<iostream>
#include<fstream>
using namespace std;
void removespaces() {
	char a;
	ifstream fin("input.txt");
	ofstream temp("file.txt");
	if (!fin) {
		cout << "File could not be opened!" << endl;
		return;
	}
	while (fin.get(a)) {
		if (a != ' ') {
			temp << a;
		}
	}
	fin.close();
	temp.close();
	ofstream write("input.txt");
	ifstream read("file.txt");
	while(read.get(a)) {
		write<< a;
	}
	write.close();
	read.close();
	cout << "spaces sucssesfully remove in file" << endl;

}
int main()
{
	removespaces();






}