#include<iostream>
using namespace std;
void palindrom(int a) {
	int num = a;
	int reverse = 0;
	while (num> 0) {
		int lastdigit = num % 10;
		reverse = reverse * 10 + lastdigit;
		num = num / 10;

	}
	if (a == reverse) {
		cout << "number is palindrome" <<endl;
	}
	else {
		cout << "number is not palindrome" << endl;
	}
}
int main()

{
	int num;
	cout << "enter number:";
	cin >> num;

	palindrom(num);


	return 0;

}