#include<iostream>
using namespace std;
void sum(int a) {
	int sum = 0;
	for (int i =1; i <= a; i++) {
		sum += i;
	}
	cout << "sum of numbers from 1 to  " << a << ": " << sum;
}
int main() {
	int num;
	cout << "enter number:";
	cin >> num;
	sum(num);


}