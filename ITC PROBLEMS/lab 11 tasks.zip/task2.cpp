#include<iostream>
using namespace std;
int main()
{
	const int size = 5;
	int arr[size];
	for (int i = 0; i < size; i++) 
	{
		cout << "enter number:";
		cin >> arr[i];
	}
	int min = arr[0];
	int secondmin = arr[size-1];
	for (int i = 0; i < size; i++){
		if (min > arr[i]) {
			min = arr[i];
		}
		

	}
	for (int i =0; i <size; i++) {
		
		if (secondmin>arr[i] && arr[i] != min) {
			secondmin = arr[i];
		}

	}
	
	cout << secondmin;





}