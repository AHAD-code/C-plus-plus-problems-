#include<iostream>
using namespace std;
int main()
{
	int arr1[3], arr2[3], arr3[6];
	cout << "enter 3 number of first array:";
	for (int i = 0; i < 3; i++) {
		cin >> arr1[i];
	}
	cout << "enter 3 number of second array:";
	for (int i = 0; i < 3; i++) {
		cin >> arr2[i];
	}
	for (int i = 0; i < 3; i++) {
		arr3[i] = arr1[i];

	}
	int j = 0;
	for (int i = 3; i < 6; i++) {
		arr3[i] = arr2[j];
		j++;

	}
	
	for (int j = 0; j <6; j++) {
		int index = j;


		int min = arr3[j];
		for (int i = j + 1; i <6; i++) {
			if (min > arr3[i]) {
				min = arr3[i];
				index = i;

			}
		}

		int temp = arr3[index];
		arr3[index] = arr3[j];
		arr3[j] = temp;
	}
	for (int i = 0; i <6; i++) {
		cout <<arr3[i];


	}

}