#include<iostream>
using namespace std;
int main()
{
	const int size = 5;
	int arr[size];
	int even=0, odd=0;
	for (int i = 0; i < size; i++)
	{
		cout << "enter number:";
		cin >> arr[i];
	}
	for (int i = 0; i < size; i++) {
		if (arr[i] % 2 == 0) {
			even++;
		}
		else {
			odd++;
		}
	}
	cout << "even:"<<even << endl;
	cout << "odd:" << odd << endl;
	





}