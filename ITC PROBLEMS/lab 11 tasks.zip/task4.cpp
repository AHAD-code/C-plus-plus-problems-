#include<iostream>
using namespace std;
int main()
{
	const int size = 5;
	int arr[size];
	
	bool dublicate = false;
	for (int i = 0; i < size; i++)
	{
		cout << "enter number:";
		cin >> arr[i];
	}
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (arr[i] == arr[j] && i != j) {
				dublicate = true;
				
				
			}
			
		}
		
	}
	if (dublicate == true) {
		cout << "yes dublicate exist";
	}
	else {
		cout << "dublicate not exist";
	}







}