#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int  x1, y1=0, x2, y2, x3, y3;
	cout << "enter first point:";
	cin >> x1 >> x2;
	cout << "enter second point:";
	cin >> x2>> y2;
	cout << "enter third point:";
	cin >> x3 >> y3;
	int  distanceAB, distanceBC, distanceCA;
	distanceAB = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	distanceBC = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
	distanceCA = sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));
	if (distanceAB == distanceBC && distanceAB != distanceCA) {
		cout << "its a isoselice";
	}
	else if (distanceAB == distanceCA && distanceAB != distanceBC) {
		cout << "its a isoselice";
	}
	else if (distanceBC == distanceAB && distanceBC != distanceCA) {
		cout << "its a isoselice";
	}
	else if (distanceBC == distanceCA && distanceBC != distanceAB) {
		cout << "its a isoselice";
	}
	else if (distanceCA == distanceAB && distanceCA != distanceBC) {
		cout << "its a isoselice";
	}
	else if (distanceCA == distanceBC && distanceCA != distanceAB) {
		cout << "its a isocelice";
	}
	else if (distanceAB == distanceBC && distanceAB == distanceCA) {
		cout << "its a equilatoral";
	}
	else if (distanceAB * distanceAB + distanceBC * distanceBC == distanceCA) {
		cout << "its a right trighangle";
	}
	else if (distanceAB * distanceAB + distanceCA * distanceCA == distanceBC) {
		cout << "its a right trighangle";
	}
	else if (distanceBC * distanceBC + distanceCA * distanceCA == distanceAB) {
		cout << "its a right trighangle";
	}
	else if (distanceAB != distanceBC != distanceCA) {
		cout << "its a  scalene triangle";

	}
	else {
		cout << "its not isocelice not right not  scalene triangle";
	}
















}