#include<iostream>
using namespace std;
int main()
{
	double value;
	cout << "enter value:";
	cin >> value; 
	char ch;
	cout << "Choose the type of conversion:\n";
	cout << "I -> Inches to Centimeters\n";
	cout << "C -> Centimeters to Inches\n";
	cout << "G -> Gallons to Liters\n";
	cout << "L -> Liters to Gallons\n";
	cout << "M -> Miles to Kilometers\n";
	cout << "K -> Kilometers to Miles\n";
	cout << "P -> Pounds to Kilograms\n";
	cout << "O -> Pounds to Ounces\n";
	cout << "F -> Fahrenheit to Celsius\n";
	cout << "S-> Celsius to Fahrenheit\n";
	cout << "Enter your choice (I, C, G, L, M, K, P, O, F, or S): ";
	cin >> ch;
	if (ch == 'I') {
		cout << "conversion=" << value * 2.52 << "centimeter";
		}
	else if (ch == 'C') {
		cout << "conversion=" << value * 0.393701 << "inch";
	}
	else if (ch == 'G') {
		cout << "coversion" << value * 3.78541 << "liter";
	}
	else if (ch == 'L') {
		cout << "coversion" << value *  0.264172 << "gallon";
	}
	else if (ch == 'M') {
		cout << "coversion" << value * 1.60934 << "kilometer";
	}
	else if (ch == 'K') {
		cout << "coversion=" << value *  0.621371 << "miles";
	}
	else if (ch == 'P') {
		cout << "coversion=" << value *1 << "kilogram";
	}
	else if (ch == 'O') {
		cout << "coversion=" << value * 16 << "ounce";
	}
	else if (ch == 'F') {
		cout << "coversion=" <<(value-32)*5/9<< "celcius";
	}
	else if (ch == 'S') {
		cout << "coversion=" << value*(9/5)+32 << "fahrenhite";
	}
	else {
		cout << "invalid input";
	}
	return 0;








}