#include<iostream>
using namespace std;
int main()
{
	float water;
	cout << "enter the amount of water you drink in a day:";
	cin >> water;
	if (water < 1.5) {
		cout << "dink more water for better health";

	}
	
	 else if (water > 1.5 && water < 2.5) {
		cout << "you are well hydrated";
		}
	else {
		cout << "great job staying hydrated";
	}








}