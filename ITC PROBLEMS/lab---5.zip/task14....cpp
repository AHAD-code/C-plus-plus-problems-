#include<iostream>
#include<math.h>

using namespace std;
int main()
{
	int x1, y1, x2 = 0, y2, x3, y3, x4, y4;
	cout << "enter your four points\n";
	cout << "enter x1 and y1:";
	cin >> x1 >> y1;
	cout << "enter x2 and y2:";
	cin >> x1 >> y2;

	cout << "enter x3 and y3:";
	cin >> x3 >> y3;
	cout << "enter x4 and y4:";
	cin >> x4 >> y4;
	int distance1and2, distance3and4, distance2and3, distance4and1, distance1and3, distance2and4;
	distance1and2 = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	distance2and3 = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
	distance4and1 = sqrt((x1 - x4) * (x1 - x4) + (y1 - y4) * (y1 - y4));
	distance3and4 = sqrt((x4 - x3) * (x4 - x3) + (y4 - y3) * (y4 - y3));
	distance1and3 = sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));
	distance2and4 = sqrt((x4 - x2) * (x4 - x2) + (y4 - y2) * (y4 - y2));

	cout << distance1and2 << endl;
	cout << distance2and3 << endl;
	cout << distance4and1 << endl;
	cout << distance3and4 << endl;
	cout << distance1and3 << endl;
	cout << distance2and4 << endl;

	if (distance1and2 == distance3and4 && distance1and3 == distance2and4) {
		cout << "points are cooardinater of rectangle" << endl;
	}
	else if (distance1and2 == distance2and3 && distance1and2 == distance3and4 && distance1and2 == distance4and1) {
		cout << "this is square" << endl;
	}
	else {
		cout << "its a qudrilatoral" << endl;
	}









}