#include<iostream>
using namespace std;
int main()
{
	char a;
	cout << "enter the letter:";
	cin >> a;
	int b = a;
	if (b >= 65 && b <= 90){

		cout << "number is capital:";

	}

	else if (b >= 97 && b <= 122){
		cout << "number is small letter:";
	}
	else {
		cout << "your number is not letter";
		return 0;

	}





}