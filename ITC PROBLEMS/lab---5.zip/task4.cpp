#include<iostream>
using namespace std;
int main()
{
	int a;
	cout << "enter your age:";
	cin >> a;
	if (a >= 18){

		cout << "eligible to vote" << endl;

	}

	else if (a < 18){
		cout << "not eligible" << endl;
	}
	else if (a <= 0){
		cout << "invalid age enter";
	}


}