#include<iostream>
using namespace std;
int main()
{
	int sub1, sub2, sub3;
	cout << "enter subject 1 marks";
	cin >> sub1;
	cout << "enter subject 2 marks";
	cin >> sub2;
	cout << "enter subect 3 markas";
	cin >> sub3;
	double average;
	average = (sub1 + sub2 + sub3) / 3;
	if (average >= 40) {
		cout << "pass";
	}
	
	else if (sub1 < 33 || sub2 < 33 || sub3 < 33) {
		cout << "fail due to subject score";
	}
	else {
		cout << "fail";
	}





}