#include<iostream>
using namespace std;
int main()
{
	int days;
	cout << "enter number of days a book is overdue:";
	cin >> days;
	if (days <= 7){
		cout << "no fine" << endl;
	}

	if (days <= 14 && days > 7){
		cout << "$5" << endl;
	}

	if (days <= 30 && days > 14){
		cout << "$10" << endl;
	}

	if (days > 30){
		cout << "$25" << endl;
	}
	else {
		cout << "invalid input" << endl;
	}
}