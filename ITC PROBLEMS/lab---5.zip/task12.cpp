#include<iostream>
using namespace std;
int main()
{
	int player1, player2;
	cout << "enter number player 1:";
	cin >> player1;
	cout << "enter number player 2:";
	cin >> player2;
	if (player1 == 1 && player2 == 3) {
		cout << "player 1 is win";

	}
	else if (player1 == 2 && player2 == 1) {
		cout << "player 1 is win";
	}
	else if (player1 == 3 && player2 == 2) {
		cout << "player 1 is win";
	}
	else {
		cout << "player 2 is win";
	}




}