#include<iostream>
using namespace std;
int main()
{
	int weight;
	cout << "enter weight:";
	cin >> weight;
	if (weight <= 5) {
		cout << "shiping fee:$5";
	}
	 else if (weight > 5 && weight <= 20) {
		cout << "shiping fee:$10";
	}
	else{
		cout << "shiping fee:$20";
	}
	return 0;





}