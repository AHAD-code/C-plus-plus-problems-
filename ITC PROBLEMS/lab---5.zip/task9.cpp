#include<iostream>
using namespace std;
int main() 
{
	int age;
	cout << "enter your age:";
	cin >> age;
	if (age <= 12) {
		cout << "tiket price:$8";
	}
	else if (age >= 13 && age <= 59) {
		cout << "tiket price:$12";
	}
	else {
		cout << "tiket price :$6";

	}

	return 0;






}