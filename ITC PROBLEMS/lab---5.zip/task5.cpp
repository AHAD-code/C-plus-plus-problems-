#include<iostream>
using namespace std;
int main()

{
	int num;
	cout << "enter yuor number:";
	cin >> num;
	if (num >= 90 && num <= 100){
		cout << "GRADE A" << endl;
	}
	else if (num >= 80 && num <= 89){
		cout << "GRADE B" << endl;
	}

	else if (num >= 70 && num <= 79){
		cout << "GRADE C" << endl;
	}
	else if (num >= 60 && num <= 69){
		cout << "GRADE D" << endl;
	}
	else if (num<60){
		cout << "fail";
	}
	else {
		cout << "invalid input" << endl;
	}
	return 0;


}