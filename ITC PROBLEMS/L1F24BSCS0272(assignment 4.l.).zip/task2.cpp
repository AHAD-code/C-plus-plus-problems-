#include <iostream>
using namespace std;

int main() {
    const int size = 100;
    char arr[size];
    char arr2[size];
    int index[20];
    int b = 0;
    int word_count = 0;

    cout << "Enter words: ";
    cin.getline(arr, size);

    char temp[15];
    int start = 0;
    int end = 0;
    int a = 0;

    for (int i = 0; arr[i] != '\0'; i++) {
        if (arr[i] >= 'a' && arr[i] <= 'z' || arr[i] >= 'A' && arr[i] <= 'Z') {
            start = i;


            for (int j = start; arr[j] != ' ' && arr[j] != '\0'; j++) {
                end = j;
            }

            a = 0;
            for (int k = start; k <= end; k++) {
                temp[a++] = arr[k];
            }
            temp[a] = '\0';


            int count = 0;
            for (int l = 0; temp[l] != '\0'; l++) {
                if (temp[l] == 'a' || temp[l] == 'e' || temp[l] == 'i' || temp[l] == 'o' || temp[l] == 'u' ||
                    temp[l] == 'A' || temp[l] == 'E' || temp[l] == 'I' || temp[l] == 'O' || temp[l] == 'U') {
                    count++;
                }
            }


            if (count > 2) {
                index[word_count++] = b;

                for (int m = 0; temp[m] != '\0'; m++) {
                    arr2[b++] = temp[m];
                    
                }
                arr2[b++] = ' ';

            }

            i = end;
        }
    }

    arr2[b] = '\0';


    cout << "Vowels: " << arr2 << endl;
    cout << "INDEX: ";
    for (int i = 0; i < word_count; i++) {
        cout << index[i] << " ";
    }
    cout << endl;

    return 0;
}
