#include<iostream>
using namespace std;
int main()
{
	const int size = 100;
	char arr[size];
	cout << "enter character pairs:";
	cin.getline(arr, size);
	int count = 0;
	cout << "same characters of this array:";
	for (int i = 0; arr[i] != '\0'; i++) {

		if (arr[i] != ' ' && arr[i] == arr[i + 1]) {
			cout << arr[i] << arr[i + 1] << " ";
			count++;
		}


	}
	cout << endl;
	cout << "same character:";
	cout << count;



}