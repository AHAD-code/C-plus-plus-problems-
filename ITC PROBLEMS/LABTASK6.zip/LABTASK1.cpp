#include<iostream>
using namespace std;
int main()
{
	int num;
	num = 0;
	int sum = 0;
  while ( num >= 0) {
	  sum=sum + num;
	  cin >> num;
	}
  cout << sum;






}