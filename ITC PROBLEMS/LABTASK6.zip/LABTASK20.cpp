#include<iostream>
using namespace std;
int main()
{

	int start, end,x;
	cout << "enter start:";
	cin >> start;
	cout << "enter end:";
	cin >> end;
	cout << "enter number:";
	cin >> x;
	cout << "number divisible=";
	for (int i = start; i <= end; i++){

		if (i%x== 0){
			cout << i << "  ";
		}



	}















}