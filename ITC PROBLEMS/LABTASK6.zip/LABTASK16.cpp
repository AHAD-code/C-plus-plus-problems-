#include<iostream>
using namespace std;
int main()
{

	int base, exp, result;
	cout << "enter base:";
	cin >> base;
	cout << "enter exponent:";
	cin >> exp;
	for (int i = 1; i <= exp; i++){

		result = base*i;


	}
	cout << "result=" << result << endl;





}