#include<iostream>
using namespace std;
int main()
{
	int num, reverse;
	cout << "enter number:" << endl;
	cin >>num;
	cout << "reverse number:";
	while (num > 0) 
	{
		reverse = num % 10;
		num = num / 10;
		cout << reverse;
	}
	return 0;



}