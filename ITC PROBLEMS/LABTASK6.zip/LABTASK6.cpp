#include<iostream>
using namespace std;
int main()
{
	int  sum = 0, count = 0, average;
	
	while (true) {
		int num;
		cout << "enter your numbers:";

		cin >> num;
		if (num == -1) {
			break;
		}
		sum = sum + num;
		count++;
		
	}
	average = sum / count;
	cout << "average=" << average;



}