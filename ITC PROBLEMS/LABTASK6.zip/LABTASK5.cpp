#include<iostream>
using namespace std;
int main()
{
	int num=1, positive=0, negative=0;
	cout << "enter integers";
	
	while (num != 0) {
		cin >> num;
		if (num > 0) {
			positive = positive + 1;
		}
		else if (num < 0) {
			negative = negative + 1;
		}



	}
	cout << "number of positive integer:";
	cout << positive << endl;
	cout << "number of negative integer:";
	cout << negative;




}
