#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "enter number:";
	cin >> n;
	int count;
	count = 0;
	cout << "odd number:";
	for (int i=1; i<=n; i=i+2) {
		
		if (i % 2 != 0) {
			cout << i << " ";
			count++;
			
		}
		
	}
	cout << endl;
	cout << "total count:";
	cout << count << endl;





}