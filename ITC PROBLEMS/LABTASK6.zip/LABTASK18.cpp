#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number";
	cin >> num;
	for (int i = 1; i <= num; i++){
		int square = i * i;
		cout << i << "^" << "2" << "=" << square << endl;



	}
}