#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number:";
	cin >> num;
	for (int i = 1; i <= num; i++) {
		int product = num * i;
		cout << num << "*" << i <<"=" << product << endl;
	}






}