#include<iostream>
using namespace std;
int main()
{

	int num, sum=0;
	cout << "enter number:";
	cin >> num;
	for (int i = 1; i <= num; i = i + 2){
		sum = sum + i;
	}
	cout << "sum of odd number:" << sum << endl;








}