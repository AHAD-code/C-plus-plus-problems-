#include<iostream>
using namespace std;
int main()
{
	int num, r, sum=0;
	cout << "enter positive integer:";
	cin >> num;
	while (num!=0)
	{
		r = num % 10;
		num = num / 10;
		sum = sum + r;
		
	}
	cout << "sum of integer:" << sum << endl;










}