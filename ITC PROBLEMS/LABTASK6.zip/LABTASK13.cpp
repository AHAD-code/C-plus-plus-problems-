#include<iostream>
using namespace std;
int main()
{

	int num, product=1;
	cout << "enter your number:";
	cin >> num;
	for (int i = 1; i <= num; i++){
		product = product*i;

	}
	cout << "factorial is:" << product << endl;






}