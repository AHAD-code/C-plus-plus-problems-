#include<iostream>
using namespace std;
int main()
{
	int num, digite, product=1;
	cout << "enter your number:";
	cin >> num;
	while (num > 0)
	{
		digite=num % 10;
		product = product * digite;
		num = num / 10;

	}
	cout << "product=" << product;
	return 0;



}