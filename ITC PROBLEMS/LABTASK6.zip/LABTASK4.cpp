#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number:";
	cin >> num;
	int sum = 0;
	for (int i = 2; i <= num; i=i+2) {
		if(i%2==0)
		{
			sum = sum + i;
		
		}
	}
	cout << "sum of even number:";
	cout << sum;





}