#include<iostream>
using namespace std;
int main()
{
	int num, max;
	cout << "enter number";
	cin >> num;
	max = num;
	while (num != 0){
		cout << "enter number";
		cin >> num;
		if (num > max)
		{
			max = num;
		}




	}
	cout <<"maximum number:"<< max;



}