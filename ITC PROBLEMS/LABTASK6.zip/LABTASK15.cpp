#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number";
	cin >> num;
	for (int i = 2; i <= num; i++) {
		if (num % i == 0) {
			cout << "its not a prime number";
			i = num;
		}
		else {
			cout << "its a prime number";
			i = num;
		}


	}
}