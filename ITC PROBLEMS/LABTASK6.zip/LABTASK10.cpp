#include<iostream>
using namespace std;
int main()
{
	int n, count = 0;
	cout << "enter your number:";
	cin >> n;
	for (int i = 1; i <= n; i++) {
		if (i % 2 == 0) {
			count++;
		}
	}
	cout << "number divisors:" << count;
	return 0;
		
	
	



}