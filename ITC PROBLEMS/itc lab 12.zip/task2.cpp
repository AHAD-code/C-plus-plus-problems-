#include<iostream>
using namespace std;
int main()
{
	const int size = 8;
	int arr[size];
	int choice;
	cout << "enter integers:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	cout << "enter 1 for sorting in  accending order:" << endl;
	cout << "enter 2 for sorting in decending order";
	cin >> choice;
	if (choice == 1) {
		for (int i = 0; i < size; i++) {
			int index = i;
			for (int j = i + 1; j < size; j++) {
				if (arr[index] > arr[j]) {
					index = j;
				}
			}
			int temp = arr[index];
			arr[index] = arr[i];
			arr[i] = temp;
		}
		cout << "sorted array in accending order:";
		for (int k = 0; k < size; k++) {
			cout << arr[k] << " ";
		}
	}
	else if (choice == 2) {
		for (int i = 0; i < size; i++) {
			int index = i;
			for (int j = i + 1; j < size; j++) {
				if (arr[index] <arr[j]) {
					index = j;
				}
			}
			int temp = arr[index];
			arr[index] = arr[i];
			arr[i] = temp;
		}
		cout << "sorted array in deccending  order:";
		for (int k = 0; k < size; k++) {
			cout << arr[k] << " ";
		}
	}
	else {
		cout << "incorrect input";
	}



}