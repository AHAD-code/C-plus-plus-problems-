#include<iostream>
using namespace std;
int main()
{
	const int size = 8;
	int arr[size];
	cout << "enter integers in array:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	int target;
	cout << "enter target value for search:";
	cin >> target;
	bool f = false;
	for (int i = 0; i < size; i++) {
		if (target == arr[i]) {
			f = true;
		}
	}
	if (f == true) {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size - i - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
		cout << "sorted array in accending order:";
		for (int i = 0; i < size; i++) {
			cout << arr[i] << " ";
		}
	}
	else if (f ==false) {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size - i - 1; j++) {
				if (arr[j] < arr[j + 1]) {
					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
		cout << "sorted array in decending order:";
		for (int i = 0; i < size; i++) {
			cout << arr[i] << " ";
		}
	}



}