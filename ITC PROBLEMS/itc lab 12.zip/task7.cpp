#include<iostream>
using namespace std;
int main() {
	const int size = 8;
	int arr[size];
	cout << "enter integers of array:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	for (int i = 0; i < size; i++) {
		for (int j =0; j < size - i - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				int temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
	int target;
	cout << "enter target value:";
	cin >> target;
	bool f = false;
	for (int i = 0; i < size; i++) {
		if (target == arr[i]) {
			f = true;
		}
	}
	if (f == true) {
		cout << "target value found" << endl;
	}
	else {
		cout << "target value not found" << endl;
	}
	cout << "sorted array:";
	for (int i = 0; i < size; i++) {
		cout << arr[i] << " ";
	}


}