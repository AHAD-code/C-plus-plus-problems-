#include<iostream>
using namespace std;
int main()
{
	const int size = 8;
	int arr[size];
	cout << "enter integers of array:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	cout << endl;
	int num;
	int index;
	cout << "enter target value:";
	cin >> num;
	bool f = false;
	for (int i = 0; i < size; i++) {
		if (arr[i] == num) {
			f = true;
			index = i;
			break;
		}
	}
	if (f == true) {
		cout << "target value found in array" << endl;
		cout << "index:" << index;
	}
	else if(f==false){
		cout << "target value not found in array";
	}



}