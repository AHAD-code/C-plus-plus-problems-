#include<iostream>
using namespace std;
int main()
{
	const int size =8;
	int arr[size];
	cout << "enter elements of array:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	for (int i = 0; i < size; i++) {
		int index = i;
		for (int j = i + 1; j < size; j++) {
			if (arr[index]> arr[j]) {
				index = j;
			}
				
		}
		int temp = arr[index];
		arr[index] = arr[i];
		arr[i] = temp;
	}
	cout << "sorted array:";
	for (int i = 0; i < size; i++) {
		cout << arr[i] << " ";
	}


}