#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number of unit you want to buy:";
	cin >> num;
	double price = num * 499;
	if (num >= 1 && num <= 10) {
		double discount;
		discount = price - (price* 5 / 100);

		cout << "your total price with 5%discount:" << discount;
	}
	 else if (num >=11 && num <=25 ) {
		double discount;
		discount = price - (price * 10 / 100);

		cout <<"your total price with 10%discount:"<< discount;
	}
	 else if (num >= 26 && num <= 50) {
		double discount;
		discount = price - (price * 15 / 100);

		cout << "your total price with 15%discount:" << discount;
	}
	 else if (num >= 50 && num <= 100) {
		double discount;
		discount = price - (price * 20/ 100);

		cout << "your total price with 20%discount:" << discount;
	}
	 else if (num>100) {
		double discount;
		discount = price - (price * 30 / 100);

		cout << "your total price with 30%discount:" << discount;
	}
	else {
		cout << "invalid input";
	}
	return 0;






}