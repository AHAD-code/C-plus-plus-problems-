#include<iostream>
using namespace std;
int main()
{
	char uberservices;
	cout << "Uber Current Services\n";
	cout << "(M=uber moto\tA=uber auto\tG=uber go)" << endl;
	cout << "       Enter one in M,A,G " << endl;
	cout << "Your choice:";
	cin >> uberservices;
	if (uberservices == 'M' || uberservices == 'm') {
		int mkm;
		cout << "enter number of km you want travel:";
		cin >> mkm;
		int time;
		cout << "Enter your expected time to reach the destination:";
		cin >> time;
		int signal;
		cout << "enter number of signal crossings on the way:";
		cin >> signal;
		double signaltime;
		signaltime = signal * 150;
		double signalminute = signaltime * 0.0167;
		double totaltime;
		totaltime = time + signalminute;
		double  moterfare = 15;
		double perkm = 2 * mkm;
		double  permin = 1 * totaltime;
		double  totalfare = moterfare + perkm + permin;
		cout << "Your Choice=Uber Moter\n";
		cout << "basic fare=" << moterfare << endl;
		cout << "kilometer fare=" << perkm << endl;
		cout << "time fare=" << permin << endl;
		cout << "total fare=" << totalfare << endl;

	}
	if (uberservices == 'A' || uberservices == 'a') {
		double  Akm;
		cout << "enter number of km you want travel:";
		cin >> Akm;
		double time;
		cout << "Enter your expected time to reach the destination:";
		cin >> time;
		double signal;
		cout << "enter number of signal crossings on the way:";
		cin >> signal;
		double  signaltime;
		signaltime = signal * 150;
		double  signalminute = signaltime * 0.0167;
		double  totaltime;
		totaltime = time + signalminute;
		double autofare = 33;
		double  perkm = 4 * Akm;
		double permin = 2 * totaltime;
		double  totalfare = autofare + perkm + permin;
		cout << " Your choice=Uber Auto\n";
		cout << "basic fare=" << autofare << endl;
		cout << "kilometer fare=" << perkm << endl;
		cout << "time fare=" << permin << endl;
		cout << "total fare=" << totalfare << endl;


	}
	if (uberservices == 'G' || uberservices == 'g') {
		double  Gkm;
		cout << "enter number of km you want travel:";
		cin >> Gkm;
		double  time;
		cout << "Enter your expected time to reach the destination:";
		cin >> time;
		double  signal;
		cout << "enter number of signal crossings on the way:";
		cin >> signal;
		double  signaltime;
		signaltime = signal * 150;
		double  signalminute = signaltime * 0.0167;
		double  totaltime;
		totaltime = time + signalminute;
		double  gofare = 75;
		double  perkm = 12 * Gkm;
		double  permin = 3.8 * totaltime;
		double  totalfare = gofare + perkm + permin;
		cout << " Your choice=Uber GO\n";
		cout << "basic fare=" << gofare << endl;
		cout << "kilometer fare=" << perkm << endl;
		cout << "time fare=" << permin << endl;
		cout << "total fare=" << totalfare << endl;


	}
	



















}