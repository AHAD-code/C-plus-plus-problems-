#include<iostream>
using namespace std;
int main()
{
	int numpeopel;
	cout << "Enter number of people with your:";
	cin >> numpeopel;
	cout << "Emporium cinema is offering three different type of tickets for the film" << endl;
	cout << "S=Student\tN=Normal\tE=Executive" << endl;
	cout << "your choice:";
	char ticket;
	cin >> ticket;
	if (ticket == 'S' || ticket == 's') {
		int ticketprice = 250;
		int totalticketprice = ticketprice * numpeopel;
		cout << "popcorne stall offer three types of popcorns" << endl;
		cout << "S=Simple= 100\t T=Tacos =150 \t C=Caramel= 200" << endl;
		cout << "Choice in S,T,C " << endl;
		char popcon;

		cin >> popcon;
		if (popcon == 'S' || popcon == 's') {
			int small = 100;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << small << endl;
			int total = totalticketprice + small;
			cout << "total use amount=" << total;
		}
		else if (popcon == 'T' || popcon == 't') {
			int tacos = 150;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << tacos << endl;
			int total = totalticketprice + tacos;
			cout << "total use amount=" << total;

		}
		 else if (popcon == 'C' || popcon == 'c') {
			int caramel =200;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << caramel << endl;
			int total = totalticketprice + caramel;
			cout << "total use amount=" << total;

		}
		 else {
			cout << "invalid input";
		}
		
	}
	else if (ticket == 'N' || ticket == 'n') {
		int ticketprice = 400;
		int totalticketprice = ticketprice * numpeopel;
		cout << "popcorne stall offer three types of popcorns" << endl;
		cout << "S=Simple= 100\t T=Tacos =150 \t C=Caramel= 200" << endl;
		cout << "Choice in S,T,C " << endl;
		char popcon;

		cin >> popcon;
		if (popcon == 'S' || popcon == 's') {
			int small = 100;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << small << endl;
			int total = totalticketprice + small;
			cout << "total use amount=" << total;
		}
		else if (popcon == 'T' || popcon == 't') {
			int tacos = 150;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << tacos << endl;
			int total = totalticketprice + tacos;
			cout << "total use amount=" << total;

		}
		else if (popcon == 'C' || popcon == 'c') {
			int caramel = 200;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << caramel << endl;
			int total = totalticketprice + caramel;
			cout << "total use amount=" << total;

		}
		else {
			cout << "invalid input";
		}


	}
	 else if (ticket == 'E' || ticket == 'e') {
		int ticketprice = 750;
		int totalticketprice = ticketprice * numpeopel;
		cout << "popcorne stall offer three types of popcorns" << endl;
		cout << "S=Simple= 100\t T=Tacos =150 \t C=Caramel= 200" << endl;
		cout << "Choice in S,T,C " << endl;
		char popcon;

		cin >> popcon;
		if (popcon == 'S' || popcon == 's') {
			int small = 100;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << small << endl;
			int total = totalticketprice + small;
			cout << "total use amount=" << total;
		}
		 else if (popcon == 'T' || popcon == 't') {
			int tacos = 150;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << tacos << endl;
			int total = totalticketprice + tacos;
			cout << "total use amount=" << total;

		}
		 else if (popcon == 'C' || popcon == 'c') {
			int caramel = 200;
			cout << "total amount used for the film=" << totalticketprice << endl;
			cout << "total amount use for popcorn=" << caramel << endl;
			int total = totalticketprice + caramel;
			cout << "total use amount=" << total;

		}
		 else {
			cout << "invalid input";
		}


	}
	else {
		cout << "invalid input";
	}



}