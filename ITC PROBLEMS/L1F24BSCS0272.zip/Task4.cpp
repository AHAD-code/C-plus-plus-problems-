#include<iostream>
using namespace std;
int main()
{
	float starttime, endtime;
	cout << "enter starting time:";
	cin >> starttime;
	cout << "enter end time:";
	cin >> endtime; int timea = starttime;
	int timea1 = timea * 60;
	double timeb = starttime - timea;
	double timeb1 = timeb * 100;


	int time1 = endtime;
	int time11 = time1 * 60;
	double timemin = endtime - time1;
	double timemin1 = timemin * 100;

	double starttotal = timea1 + timeb1;
	double endtotal = time11 + timemin1;

	double totalmin = endtotal - starttotal;

	if (timea>=0&&time1<=24&&timeb1<59&&timemin1<59&&totalmin<420&& starttime < endtime) {
		double price = totalmin * 0.12;
		cout << "your charges=" << price;
	}
	else if (timea >= 0 && time1 <= 24 && timeb1 < 59 && timemin1 < 59&&totalmin<=1140 && starttime < endtime) {
		int price2 = totalmin * 0.55;
		cout << "your charges=" << price2;
	}
	else if (timea >= 0 && time1 <= 24 && timeb1 < 59 && timemin1 < 59&&totalmin<1440 && starttime < endtime) {
		int price3 = totalmin * 0.35;
		cout << "your charges=" << price3;
	}
	else {
		cout << "invalid input";
	}
}