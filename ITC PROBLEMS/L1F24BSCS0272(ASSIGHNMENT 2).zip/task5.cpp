#include<iostream>
using namespace std;
int main()
{
	int numeratior, denominatior, a, b;
	cout << "enter numeratior:";
	cin >> numeratior;
	a = numeratior;
	cout << "enter denomeratior:";
	cin >> denominatior;
	b = denominatior;
	for (int i = 1; i < numeratior  && i < denominatior ; i++) {

		if (numeratior % i == 0 && denominatior % i == 0) {
			numeratior = numeratior / i;
			denominatior = denominatior / i;
		}


	}
	if (a != numeratior && b != denominatior) {
		cout << "numeratior=" << numeratior << endl;
		cout << "denominatior=" << denominatior << endl;
	}
	if (a == numeratior && b == denominatior) {
		cout << "already lower possible term ";
	}




}