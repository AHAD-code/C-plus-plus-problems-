#include<iostream>
using namespace std;
int main()
{
	int num, min , max;
	cout << "enter number:";
	cin >> num;
	min = num;
	max = num;
	while (num > 0||num<0) {
		cout << "enter number:";
		cin >> num;
		if (num == 0) {
			num = 0;
		}
		else if (min > num) {
			min = num;
		}
		else if (max < num) {
			max = num;
		}
	}

	cout << "max=" << max;
	cout << "min=" << min;



}