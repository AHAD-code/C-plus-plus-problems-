#include<iostream>
using namespace std;
int main()
{
	int num, num1 = 0, num2 = 1, newnum = 0;
	cout << "enter number:";
	cin >> num;
	if (num < 0) {
		cout << "invalid input please enter positive input:";
	}
	else {
		for (int i = 2; i < num; i++) {
			if (num == 1) {
				newnum = 0;

			}
			else if (num == 2) {
				newnum = 1;
			}
			else {
				newnum = num1 + num2;
				num1 = num2;
				num2 = newnum;
			}

		}
		cout << num << "term:";
		cout << newnum << " ";


	}


}