#include<iostream>
using namespace std;
int main()
{
	int num1, num2;
	cout << "enter first number:";
	cin >> num1;
	cout << "enter second number:";
	cin >> num2;
	


	for (int i = num1 + 1; i < num2; i++) {
		cout << (char)i << " ";
	

	}





}