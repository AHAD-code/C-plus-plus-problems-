#include<iostream>
using namespace std;
int main()
{
	int cookies = 40;
	int serving = 10;
	int calories_perserving=300;
	int calories_percookies;
	calories_percookies = (calories_perserving * serving) / cookies;
	int cookies_eat;
	cout << "enter cookies you eat:";
	cin >> cookies_eat;
	int caloriesconsume = cookies_eat * calories_percookies;
	cout << "calories you consume" << caloriesconsume << endl;
	return 0;













}