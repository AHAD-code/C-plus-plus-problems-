#include<iostream>
using namespace std;
int main()
{
	int meal1=50, meal2=30, meal3=20;
	int soldm1, soldm2, soldm3;
	cout << "how meany meals1 sold: ";
	cin >> soldm1;
	cout << "how meany meals2 sold: ";
	cin >> soldm2;
	cout << "how meany meals3 sold: ";
	cin >> soldm3;
	int totalrevenue;
	totalrevenue = (soldm1 * 50) + (soldm2 * 30) + (soldm3 * 20);
	cout << "total revenue:" << totalrevenue << endl;
	return 0;







}