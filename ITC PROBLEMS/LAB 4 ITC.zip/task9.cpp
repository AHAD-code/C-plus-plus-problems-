#include<iostream>
using namespace std;
int main()
{
	int width, length;
	cout << "enter the width";
	cin >> width;
	cout << "enter the length";
	cin >> length;
	double area;
	area = width*length;
	double per;
	per = 2 * (width + length);
	cout << "area of rectandl =" << area << endl;
	cout << "perimeter of rectangl=" << per << endl;
	return 0;







}