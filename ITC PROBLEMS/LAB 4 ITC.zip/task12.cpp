#include<iostream>
using namespace std;
int main()
{
	int math, chem, phy;
	cout << "enter valu of chemistry:";
	cin >> chem;
	cout << "enter valu of math:";
	cin >> math;
	cout << "enter valu of physics:";
	cin >> phy;
	int total;
	total = math + chem + phy;
	cout << "_________________________________________________________" << endl;
	cout << "MATHS\tCHEMISTRY\tPHYCICS\tTOTAL\n";
	cout << math << "\t" << chem << "\t\t" << phy << "\t" << total << endl;
	cout << "__________________________________________________________________" << endl;
	return 0;

	








}