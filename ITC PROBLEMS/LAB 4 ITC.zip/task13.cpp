#include<iostream>
using namespace std;
int main()

{
	int wheat, wheatq, rice, riceq, sugar, sugarq;
	cout << "enter price of wheat:";
	cin >> wheat;
	cout << "enter the quantity of wheat:";
	cin >> wheatq;
	cout << "enter price of rice:";
	cin >> rice;
	cout << "enter quantity of rice:";
	cin >> riceq;
	cout << "enter price of sugar:";
	cin >> sugar;
	cout << "enter quantity of sugar:";
	cin >> sugarq;
	int vwheat, vrice, vsugar;
	vwheat = wheat*wheatq;
	vrice = rice*riceq;
	vsugar = sugar*sugarq;
	cout << "__________________________________________________" << endl;
	cout << "value of wheat:" << vwheat << endl;
	cout << "value of rice:" << vrice << endl;
	cout << "value of sugar:" << vsugar<< endl;
	cout << "__________________________________________________" << endl;
	return 0;







}