#include<iostream>
using namespace std;
int main()
{
	int class1, class2, class3;
	class1 = 15;
	class2 = 12;
	class3 = 9;
	int solda, soldb, soldc;
	cout << "enter class A ticket=";
	cin >> solda;
	cout << "enter class B ticket=";
	cin >> soldb;
	cout << "enter class C ticket=";
	cin >> soldc;
	int incomea, incomeb, incomec;
	incomea = (class1*solda);
	incomeb = class2*soldb;
	incomec = class3*soldc;
	int totalamount;
	totalamount =(incomea+incomeb+incomec);
	cout << "total amount=" << totalamount << endl;
	return 0;
		









}