#include<iostream>
using namespace std;
int main()
{
	cout << "Hello Class!\n Welcome to ITC LAB_3" << endl;
	return 0;





}