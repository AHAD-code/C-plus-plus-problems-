#include<iostream>
using namespace std;
int main()
{
	int fuel, rent, bill, total;
	cout << "enter value of fuel=";
	cin >> fuel;
	cout << "enter value of rent=";
	cin >> rent;
	cout << "enter valu of bill=";
	cin >> bill;
	total = fuel + rent + bill;
	cout << "_______________________________________" << endl;
	cout << "FUEL:          " << fuel << endl;
	cout << "RENT:          " << rent << endl;
	cout << "BILL:          " << bill << endl;
	cout << "TOTAL:          " << total << endl;
	cout << "_______________________________________" << endl;

	return 0;












}