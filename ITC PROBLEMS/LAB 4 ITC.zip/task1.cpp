#include<iostream>
using namespace std;
int main()
{
	int x;
	cout << "ENTER VARIABLE VALUE=" << endl;
	cin >> x;
	cout << "VARIABLE VALUE ENTERED="<<x << endl;
	return 0;







}