#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter the number:";
	cin >> num;
	cout << "number\t\tsquare\t\tcube\t\t" << endl;
	int square =( num * num);
	int cube = (num * num * num);
	cout << num << "\t\t" << square << "\t\t" << cube << endl;
	int num1 = num+1;
	int square1 = (num1 * num1);
	int cube1 = (num1 * num1 * num1);
	cout << num1 << "\t\t" << square1 << "\t\t" << cube1 << endl;
	int num2 = num1 + 1;
	int square2 = (num2 * num2);
	int cube2 = (num2* num2 * num2);
	cout << num2 << "\t\t" << square2 << "\t\t" << cube2 << endl;
	int num3 = num2 + 1;
	int square3 = (num3 * num3);
	int cube3= (num3 * num3 * num3);
	cout << num3 << "\t\t" << square3 << "\t\t" << cube3 << endl;
	int num4 = num3 + 1;
	int square4= (num4 * num4);
	int cube4= (num4* num4 * num4);
	cout << num4 << "\t\t" << square4 << "\t\t" << cube4 << endl;
	int num5 = num4 + 1;
	int square5 = (num5 * num5);
	int cube5 = (num5* num5* num5);
	cout << num5 << "\t\t" << square5 << "\t\t" << cube5 << endl;






		return 0;






	}


