#include<iostream>
using namespace std;
int main()
{
	double radius, height ,volume,area;
	cout << "enter radius:";
	cin >> radius;
	cout << "enter height:";
	cin >> height;
	double pi = 3.14;
	volume = pi*(radius*radius)*height;
	area = 2 * pi*radius*(radius + height);
	cout << "volume of cylinder:" << volume << endl;
	cout << "surface area of cylinder:" << area << endl;
	return 0;









}