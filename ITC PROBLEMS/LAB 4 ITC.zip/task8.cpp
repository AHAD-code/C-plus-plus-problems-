#include<iostream>
using namespace std;
int main(){

	double area;
	float radius;
	float pi =3.14;
	cout << "enter the radius=";
	cin >> radius;
	area = (pi)*(radius*radius);
	cout << "area is=" << area << endl;
	return 0;










}