#include<iostream>
using namespace std;
int main()
{
	int hours, min, totalmin;
	cout << "enter hours";
	cin >> hours;
	cout << "enter minutes";
	cin >> min;
	totalmin = (hours * 60) + min;
	cout << "total minutes" << totalmin << endl;
	return 0;







}