#include <iostream>
using namespace std;
int main()
{
	int x, y;
	x = 5;
	y = 25;
	double rem;
	rem = y%x;
	cout << "remender is=" << rem << endl;
	return 0;






}
