#include <iostream>
using namespace std;
int main()
{
	int vriable;
	cout << "enter vriable=";
	cin >> vriable;
	double square;
	square = vriable*vriable;
	cout << "vriable square is =" << square << endl;
	return 0;







}