#include <iostream>
using namespace std;
int main(){

	int score1, score2, score3, score4, score5;
	cout << "enter the five score=";
	cin >> score1 >> score2 >> score3 >> score4 >> score5;
	double average;
	average = (score1 + score2 + score3 + score4 + score5) / 5;
	cout << "the average is=" << average << endl;
	return 0;










}

	






