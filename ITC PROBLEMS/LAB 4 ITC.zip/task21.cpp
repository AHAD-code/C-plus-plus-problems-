#include<iostream>
using namespace std;
int main()
{
	int basicp = 500, advancep = 1000, profesionalp = 2000;
	int basic, advance, profesional;
	cout << "number of basic courses:";
	cin >> basic;
	cout << "number of advance courses:";
	cin >> advance;
	cout << "number of profesional courses: ";
	cin >> profesional;
	int totalamount = (basic * basicp) + (advance * advancep) + (profesional * profesionalp);
	cout << "total amount without discount:" << totalamount << endl;
	double discount;
	discount = totalamount - (totalamount * 15 / 100);
	cout << "total amount with discount:" << discount << endl;
	return 0;










}