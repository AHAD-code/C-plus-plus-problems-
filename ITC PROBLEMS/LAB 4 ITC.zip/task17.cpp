#include<iostream>
using namespace std;
int main()
{
	int speed=20, time=10, distance;
	distance = speed*time;
	cout << "contents of distance:" << distance << endl;
	return 0;












}