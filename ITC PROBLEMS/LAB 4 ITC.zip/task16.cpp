#include<iostream>
using namespace std;
int main()
{
	float gallon, travel, mpg;
	gallon = 12;
	travel = 350;
	mpg = (gallon) /( travel);
	cout << "NUMBER OF MILES PER GALLON:" << mpg << endl;
	return 0;











}