#include<iostream>
using namespace std;
int main()
{

	int min, hours;
	cout << "enter minutes:";
	cin >> min;
	hours = min / 60;
	int remainmin = min % 60;
	cout << "hours=" << hours << "remain minutes=" << remainmin << endl;
	return 0;







}