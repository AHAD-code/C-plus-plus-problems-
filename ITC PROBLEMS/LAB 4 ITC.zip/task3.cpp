//#include<iostream>
//using namespace std;
//int main()
//{
//	int x = 5
//	cout << "value of x is" << x;
//	return 0;
//
//
//
//
//}
//
#include<iostream>
using namespace std;
int main()
{
	int x = 5;
		cout << "value of x is" << x;
	return 0;




}

