#include<iostream>
using namespace std;
int main()
{
	double weight, hight;
	cout << "enter your weight in kilograms:";
	cin >> weight;
	cout << "enter your hight in metera:";
	cin >> hight;
	double bmi;
	bmi = weight / (hight * hight);
	cout << "body mass index:" << bmi << endl;
	return 0;








}