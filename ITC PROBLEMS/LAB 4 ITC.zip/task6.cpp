//#include <iostream>
//using namespace std;
//int main()
//{
//	cout << "Hello word!";
//	int x = 5
//	cout << "x=" << x
//	return 0
//
//
//
//
//
//
//}
#include <iostream>
using namespace std;
int main()
{
	cout << "Hello word!";
	int x = 5;
		cout << "x=" << x;
		return 0;






}