#include<iostream>
using namespace std;
int main()
{
	int score1, score2, score3;
	cout << "enter score 1=";
	cin >> score1;
	cout << "enter score 2=";
	cin >> score2;
	cout << "enter score 3=";
	cin >> score3;
	double average;
	average = (score1 + score2 + score3) /( 3);
	cout << "average is=" << average << endl;
	return 0;








}