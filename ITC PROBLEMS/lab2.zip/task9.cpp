#include<iostream>
using namespace std;
int main()
{
	int num1, num2, num3;
	cout << "enter num1=";
	cin >> num1;
	cout << "enter num2=";
	cin >> num2;
	cout << "enter num3=";
	cin >> num3;
	int sum;
	sum = num1 + num2 + num3;
	int sub;
	sub = num1 - num2 - num3;
	int product;
	product = num1*num2*num3;
	cout << "sum=" << sum << endl;
	cout << "sub" << sub << endl;
	cout << "product" << product << endl;
	return 0;







}