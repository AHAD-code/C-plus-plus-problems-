#include<iostream>
using namespace std;
int main()
{
	int num1, num2;
	cout << "enter first number=" << endl;
	cin >> num1;
	cout << "enter your second number=" << endl;
	cin >> num2;
	int sum;
	sum = num1 + num2;
	cout << "sum of two number is="<<sum << endl;
	return 0;








}