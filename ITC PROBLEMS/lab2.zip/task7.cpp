#include<iostream>
using namespace std;
int main()
{
	int num1, num2;
	cout << "enter number 1=";
	cin >> num1;
	cout << "enter number 2=";
		cin>> num2;
		int container;
		container = num1;
		num1 = num2;
		num2 = container;
		cout << "first number" << num1 << endl;

		cout << "second number" << num2 << endl;
		return 0;











}