#include<iostream>
using namespace std;
int main()
{
	float km, mile;
	cout << "enter distance in km";
	cin >> km;
	mile = 0.621371*km;
	cout << "distance in mile=" << mile << endl;
	return 0;








}