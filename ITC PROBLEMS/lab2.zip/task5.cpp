#include <iostream>
using namespace std;
int main()
{
	int birthdate, currentyear;
	cout << "enter your birth year=";
	cin >> birthdate;
	currentyear = 2024;
	int age;
	age = currentyear - birthdate;
	cout << "your age is =" << age << endl;
	return 0;






}