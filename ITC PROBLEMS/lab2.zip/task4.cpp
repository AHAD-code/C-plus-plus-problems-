#include<iostream>
using namespace std;
int main()
{
	int length, width;
	cout << "enter length=" << endl;
	cin >> length;
	cout << "enter width" << endl;
	cin >> width;
	int area;
	area = length*width;
	cout << "Area is=" << area << endl;
	return 0;









}