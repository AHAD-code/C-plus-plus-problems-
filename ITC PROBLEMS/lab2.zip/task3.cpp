#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter number=";
	cin >> num;
	int square;
	square = num*num;
	cout << "square of this number is=" << square << endl;
	return 0;










}