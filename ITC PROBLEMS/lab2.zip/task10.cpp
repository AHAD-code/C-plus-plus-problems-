#include<iostream>
using namespace std;
int main()
{
	int num, square, cube;
	cout << "enter num=";
	cin >> num;
	square = num*num;
	cube = num*num*num;
	cout << "square is=" << square << endl;
	cout << "cube is=" << cube << endl;
	return 0;










}