#include<iostream>
using namespace std;
int main()
{
	int product1, product2, product3, product4, product5;
	cout << "enter the price of product1=";
	cin >> product1;
	cout << "enter the price of product2=";
	cin >> product2;
	cout << "enter the price of product3=";
	cin >> product3;
	cout << "enter the price of product4=";
	cin>> product4;
	cout << "enter the price of product5=";
	cin >> product4;




}