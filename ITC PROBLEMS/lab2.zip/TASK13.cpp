#include<iostream>
using namespace std;
int main()
{
	int discountrate;
	cout << "enter the discount rate:";
	cin >> discountrate;
	int pro1, pro2;
	int originalprice1=1000, originalprice2=1200;
	cout << "the original price of pro1=100" << endl;
	cout << "the original price of pro2=1200" << endl;
	int discountprice1, discountprice2;
	discountprice1 = originalprice1 - (originalprice1 * discountrate / 100);

	cout << "the discount price of product 1="<<discountprice1<<endl;
	discountprice2 = originalprice2 - (originalprice2 * discountrate / 100);
	cout << "the discount price of product 2=" << discountprice2 << endl;
	return 0;









}