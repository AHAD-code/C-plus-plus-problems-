#include<iostream>
using namespace std;
int main()
{
	cout << "My name:Ahad hafeez " << endl;
	cout << "registration number:L1F24BSCS0272" << endl;
	cout << "course register:ITC, basic electronics " << endl;
	cout << "program register:bscs"<< endl;
	cout << "univerasity:univerasity of central punjab " << endl;
	return 0;
}