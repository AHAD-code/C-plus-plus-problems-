#include<iostream>
using namespace std;
int main()
{
	double celsius, fahrenheit;
	cout << "enter temperature in celsius=" << endl;
	cin >> celsius;
	fahrenheit = celsius * 9 / 5 + 32;
	cout << "temperature in fahrenhiet is=" << fahrenheit << endl;
	return 0;








}