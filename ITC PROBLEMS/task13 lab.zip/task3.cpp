#include <iostream>
using namespace std;

int main() {
    char charArray[] = { 'A', 'B', 'C', 'D', 'E', '\0' };

    for (int i = 0; charArray[i] != '\0'; i++) {
        cout << charArray[i];
    }
    int count = 0;
    for (int j = 0; charArray[j] != '\0'; j++) {
        count++;
      }
    cout << endl;
    cout << "length of array:" << count;

    return 0;
}
