#include <iostream>
using namespace std;

int main() {
    const int size = 10;
    
    char charArray[size];
    cout << "enter charactor:";
    cin >> charArray;
    for (int i = 0; charArray[i] != '\0'; i++) {
        if (charArray[i] == 'A' || charArray[i] == 'E' || charArray[i] == 'I' || charArray[i] == 'O' || charArray[i] == 'U' ||
            charArray[i] == 'a' || charArray[i] == 'e' || charArray[i] == 'i' || charArray[i] == 'o' || charArray[i] == 'u') {
            cout << charArray[i];
        }
    }


    return 0;
}
