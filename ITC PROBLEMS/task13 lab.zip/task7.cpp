#include <iostream>
using namespace std;

int main() {
    const int size = 10;

    char charArray[size];
    char whole[] = { 'A','E','I','O','U','a','e','i','o','u' };
    cout << "enter charactor:";
    cin >> charArray;
    for (int i = 0; charArray[i] != '\0'; i++) {
        bool f = false;
        for (int j = 0; whole[j] != 0; j++) {
            if (charArray[i] == whole[j]) {
                f = true;
            }
        }
        if (f == false) {
            cout << charArray[i];
        }
    }
    


    return 0;
}
