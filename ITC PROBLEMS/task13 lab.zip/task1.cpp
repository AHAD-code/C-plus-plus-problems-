#include <iostream>
using namespace std;

int main() {

    char charArray[] = { 'A', 'B', 'C', 'D', 'E', '\0' };
    for (int i = 0; charArray[i] != '\0'; i++) {
        cout << charArray[i];
    }
    cout << endl;
    return 0;
}
