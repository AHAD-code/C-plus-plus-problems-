#include <iostream>
using namespace std;

int main() {
    char charArray[] = { 'A', 'B', 'C', 'D', 'E', '\0' };

    for (int i = 0; charArray[i] != '\0'; i++) {
        if (i % 2 == 0) {
            cout << charArray[i];
        }
    }
    
    return 0;
}

