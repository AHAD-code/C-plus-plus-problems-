#include<iostream>
using namespace std;
int main()
{
	const int size = 10;
	int arr[10];
	cout << "enter 10 integers:";
	for (int i = 0; i < size; i++) {
		cin >> arr[i];
	}
	cout << endl;
	cout << "original arry:";
	for (int i = 0; i < size; i++) {
		cout <<arr[i]<<" ";
	}
	cout << endl;
	int min = arr[0];
	for (int i = 0; i < size; i++) {
		if (min > arr[i]) {
			min = arr[i];
		}
	}
	int max = arr[0];
	for (int i = 0; i < size; i++) {
		if (max < arr[i]) {
			max= arr[i];
		}
	}
	
	cout << "min:" << min << endl;
	cout << "max:" << max << endl;
	double sum = 0;
	for (int i = 0; i < size; i++) {
		sum = sum + arr[i];
	}
	int even=0, odd=0;
	for (int i = 0; i < size; i++) {
		if (arr[i] % 2 == 0) {
			even++;
		}
		else {
			odd++;
		}
	}
	
	cout << "sum:" <<sum<< endl;
	cout << "average:" << sum / size << endl;
	cout << "even:" << even << endl;
	cout << "odd:" << odd << endl;
	int i = 0, j= size - 1;
	
	while (i < j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
		i++;
		j--;
	}
	cout << endl;
	cout << "reverse of array:";
	for (int i = 0; i < size; i++) {
		cout << arr[i] << " ";
	}
	return 0;
}