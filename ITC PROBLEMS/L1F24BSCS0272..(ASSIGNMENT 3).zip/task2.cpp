#include<iostream>
using namespace std;
int main()
{
	const int size = 50;
	int arr[size];
	int currentsize;
	cout << "enter the number of elements of array(max-50):";
	cin >> currentsize;
	while (currentsize > 50||currentsize<1) {
		cout << "please enter number elements up to 1-50";
		cin >> currentsize;
	}
	cout << "enter elements of array:";
	for (int i = 0; i < currentsize; i++) {
		cin >> arr[i];
	}
	int num;
	int index = -1;
	cout << "enter value for serch in array:";
	cin >> num;
	for (int i = 0; i < currentsize; i++) {
		if (num == arr[i]) {
			index = i;
			break;
		}

	}
	if (index == -1) {
		cout << "value not found in array" << endl;
	}
	else {
		cout << "index of value:";
		cout << index;
	}
	cout << endl;
	for (int i = 0; i < currentsize; i++) {
		for (int j = 0; j < currentsize - i - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				int temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
	cout << "sorted array:";

	for (int i = 0; i < currentsize; i++) {
		cout << arr[i] << " ";
	}


	return 0;


}