#include<iostream>
using namespace std;
int main()
{
	int num, pro;
	cout << "enter number:";
	cin >> num;
	for (int i = 1; i <= 10; i++) {
		pro = num *i;
		cout << num << "*" << i << "=" << pro << endl;
	}



}