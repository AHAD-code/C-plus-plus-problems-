#include<iostream>
using namespace std;
int main()
{
	int num, sum=0;
	cout << "enter  number:";
	cin >> num;
	while (num > 0){
		sum = sum + num;
		cout << "enter number:";
		cin >> num;

	}
	cout << "sum=" << sum << endl;









}