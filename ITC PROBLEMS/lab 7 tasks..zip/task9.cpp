#include<iostream>
using namespace std;
int main()
{
	int num, max=0;
	cout << "enter number:";
	cin >> num;
	for (int i = 1; i > 0; i++) {
		if (max < num) {
			max = num;
		}
		if(num<0){
			break;
		}
		cout << "enter number";
		cin >> num;
		
	}
	cout << "largest number:" << max;


}