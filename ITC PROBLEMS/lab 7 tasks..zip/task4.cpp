#include<iostream>
using namespace std;
int main()
{

	int num;
	cout << "enter number";
	cin >> num;
	cout << "condown";
	for (int i = num; i > -1; i--){
		cout  <<i << " ";
	}






}