#include<iostream>
using namespace std;
int main()
{

	int num, fectorial = 1;
	cout << "enter number:";
	cin >> num;
	for (int i = 1; i <=num; i++) {
		fectorial = fectorial * i;
	}
	cout << "factorial is:" << fectorial;
}
