#include<iostream>
using namespace std;
int main()
{
	int num, even=0, odd=0;
	cout << "enter number:";
	cin >> num;
	while (num > 0) {
		if (num % 2 == 0) {
			even = even + 1;
		}
		else {
			odd = odd + 1;
		}
		cout << "enter number:";
		cin >> num;
	}
	cout << "even=" << even;
	cout << "odd=" << odd;




}