#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "enter your number:";
	cin >> num;
	for (int i = 1; i > 0; i++){
		if (num < 10){
			cout << "enter your number again:";
			cout << "invalid" << endl;
			cin >> num;
		}
		if (num>10){
			cout << "its valid number" << endl;
			cout << "number=" << num << endl;
			i = -4;
		}
	}







}