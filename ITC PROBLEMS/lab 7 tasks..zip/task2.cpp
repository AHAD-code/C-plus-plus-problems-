#include<iostream>
using namespace std;
int main()
{
	int num, sum=0;
	cout << "enter your number:";
	cin >> num;
	for (int i = 1; i < num; i++){
		if (num % i == 0){
			sum = sum + i;
		}
	}
	if (num == sum){
		cout << "number is perfect number";
	}
	else{
		cout << "its not a perfect number";
	}


}