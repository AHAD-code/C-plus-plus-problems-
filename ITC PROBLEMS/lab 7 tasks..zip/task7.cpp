#include<iostream>
using namespace std;
int main()
{
	float num1, num2;
	int oper;
	cout << "enter first number:";
	cin >> num1;
	cout << "enter first number:";
	cin >> num2;

	cout << "press 1 for addition:" << endl;
	cout << "press 2 for subtraction:" << endl;
	cout << "press 3 for multiplication:" << endl;
	cout << "press 4 for division:" << endl;
	cout << "press 0 for exit:" << endl;
	cin >> oper;
	switch (oper) {
	case 1:
		cout << num1 + num2;
		break;
	case 2:
		cout << num1 - num2; 
		break;
	case 3:
			cout << num1 * num2;
			break;
	case 4:
		cout << num1 / num2;
		break;
	case 0:
		return 0;
		

	}


}